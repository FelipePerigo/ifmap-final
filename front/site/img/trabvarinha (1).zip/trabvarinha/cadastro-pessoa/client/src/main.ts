import "./main.scss";
import "./webcomponents/input/component"; // <--- adicionado